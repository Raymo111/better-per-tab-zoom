# better-per-tab-zoom
 Better per-tab zoom Chrome extension for Chromium-based browsers
